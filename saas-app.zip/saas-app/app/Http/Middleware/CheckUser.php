<?php

namespace App\Http\Middleware;
use Auth;

use Closure;

class CheckUser
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {

        if(Auth::attempt(['email'=>($request->email), 'password'=>($request->password)])){
            echo 'Correct';
            echo "<br>" . Auth::user()->name;
            echo "<br>";
        }

        return $next($request);

    }
}