<?php

namespace App\Http\Controllers;

// use App\Crud;
use Illuminate\Http\Request;
use App\User;
use App\City;
use App\State;
class CrudController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = User::all();
        return view('crud/index', compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $states = $this->getStates();
        return view('crud/create', compact('states'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $storeData = $request->validate([
            'name' => 'required|max:255',
            'email' => 'required|max:255',
            'phone' => 'required|numeric',
            'password' => 'required|max:255',
        ]);
        $student = User::create($storeData);

        return redirect('/students')->with('completed', 'User has been saved!');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Crud  $crud
     * @return \Illuminate\Http\Response
     */
    public function show()
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Crud  $crud
     * @return \Illuminate\Http\Response
     */
    public function edit()
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Crud  $crud
     * @return \Illuminate\Http\Response
     */
    public function update()
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Crud  $crud
     * @return \Illuminate\Http\Response
     */
    public function destroy()
    {
        //
    }

    public function getCities(Request $request){
        if($request->state_id!=null){
            exit(json_encode(array('status'=>'failed','message'=>'Record not found')));
        }
        $cities = City::where(['state_id'=>$request->input('state_id')])->select('id','city')->get(); 
        echo json_encode(array('status'=>'success','message'=>'Record found', 'data'=>$cities));
    }

    public function getStates(){
        return State::select('id','state')->get();
    }
}
