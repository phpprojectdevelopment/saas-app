{{-- dd($states) --}}

@extends('layouts.master')
@section('content')
<style>
    .container {
      max-width: 850px;
    }
    .push-top {
      margin-top: 50px;
    }
    .fourty-precent-right-div, .fourty-precent-left-div{width:40%;}
    .fourty-precent-right-div{float:right}
    .fourty-precent-left-div{float:left;}
    #add_edu_year{background-color:gray;color:white;}
    #remove_edu_year{background-color:red;color:white;}
</style>

<div class="card push-top">
  <div class="card-header">
    Add User
  </div>

  <div class="card-body">
    @if ($errors->any())
      <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
        </ul>
      </div><br />
    @endif
      <!-- <form method="post" action="{{-- route('users.store') --}}"> -->
          <div class="form-group">
              {{csrf_field()}}
              <label for="name">Name</label>
              <input type="text" class="form-control" name="name"/>
          </div>
          <div class="form-group">
              <label for="birthdate">Birthdate</label>
              <input type="date" class="form-control" name="birthdate"/>
          </div>
          <div class="form-group">
            <label>Gender</label>
            <div class="radio">
              <label><input type="radio" name="gender" value="male" checked> Male</label>
              <label><input type="radio" name="gender" value="female"> Female</label>
            </div>
          </div>
           <div class="form-group">
              <label for="state_id">State</label>
              <select class="form-control" id="state_id" name="state_id">
                 <option value="">--Please select state--</option>
                 @foreach($states as $value)
                 <option value="{{ $value->id }}">{{ $value->state }}</option>
                 @endforeach;
              </select>
          </div>
          <div class="form-group">
              <label for="city_id">City</label>
              <select class="form-control" id="city_id" name="city_id">
                 <option>Mumbai</option>
              </select>
          </div>
          <div class="form-group">
              <input type="button" class="form-control" value="Add eductaion and completion of year" id="add_edu_year">
          </div>
          <div class="form-group" id="show_edu_year" style="display:none;">
              <input type="button" class="form-control" value="Remove eductaion and completion of year" id="remove_edu_year">
              <div class="fourty-precent-left-div">
                <label for="edu">Education</label>
                <select class="form-control" id="edu" name="edu">
                   <option value="High class">High class</option>
                   <option value="Bachelor">Bachelor</option>
                   <option value="Post graduation">Post graduation</option>
                </select>
              </div>
              <div class="fourty-precent-right-div">
                <label for="edu_completion_year">Year of completion</label>
                <input type="date" class="form-control" name="edu_completion_year"/>
              </div>
          </div>
          <br><br><br><br>
          <div class="form-group">
            <label for="profile_photo">Profile Photo</label>
            <input type="file" name="profile_photo" id="profile_photo" onchange="loadPreview(this);">
          </div>
          <div class="form-group">
            <div class="row" id="preview_profile_photo">
    
            </div>
          </div>
          <div class="form-group">
              <label for="skill">Skill</label>
              <select class="form-control" id="skill" name="skill" multiple>
                 <option>PHP</option>
                 <option>Java</option>
                 <option>Oracle</option>
                 <option>MySQL</option>
              </select>
          </div>
          <div class="form-group">
              <label for="upload_certificates">Upload Certificates</label>
              <input type="file" name="upload_certificates" id="upload_certificates" multiple>
          </div>
          <div class="form-group">        
            <div class="row" id="preview_upload_certificates">
    
            </div>
          </div>
          <div class="form-group">
              <label for="profession">Profession</label>
              <input type="text" class="form-control" name="profession">
          </div>
          <div class="form-group">
              <label for="company_name">Company Name</label>
              <input type="text" class="form-control" name="company_name">
          </div>
          <div class="form-group">
              <label for="job_started_from">Job started from</label>
              <input type="date" class="form-control" name="job_started_from">
          </div>
          <div class="form-group">
              <label for="business_name">Business name</label>
              <input type="text" class="form-control" name="business_name">
          </div>
          <div class="form-group">
              <label for="location">Location</label>
              <input type="text" class="form-control" name="location">
          </div>
          <div class="form-group">
              <label for="email">Email</label>
              <input type="email" class="form-control" name="email"/>
          </div>
          <div class="form-group">
              <label for="phone">Phone</label>
              <input type="tel" class="form-control" name="phone"/>
          </div>
          <button type="submit" class="btn btn-block btn-danger">Create User</button>
      <!-- </form> -->
  </div>
</div>
<script>
  $(document).ready(function(){
    $("#state_id").unbind('click').on("change", function(){
      getCities($(this).val());
    })
    $('#upload_certificates').on("change", function(){ //on file input change
      mutipleFileUpload('upload_certificates','preview_upload_certificates');
    });
    $("#add_edu_year").on("click",function(){
      $("#add_edu_year").hide();
      $("#show_edu_year").show();
    });
    $("#remove_edu_year").on('click',function(){
      $("#edu,#edu_completion_year").val("");
      $("#add_edu_year").show();
      $("#show_edu_year").hide();
    });
    function mutipleFileUpload(uploadField,showInDiv){
      if (window.File && window.FileReader && window.FileList && window.Blob) //check File API supported browser
        {
          var data = $("#"+uploadField)[0].files; //this file data    
          $.each(data, function(index, file){ //loop though each file
              if(/(\.|\/)(gif|jpe?g|png)$/i.test(file.type)){ //check supported file type
                  var fRead = new FileReader(); //new filereader
                  fRead.onload = (function(file){ //trigger function on successful read
                  return function(e) {
                      var img = $('<img/>').addClass('thumb').attr('src', e.target.result).css({"width":"150px", "height":"150px"}); //create image element 
                      $('#'+showInDiv).append(img); //append image to output element
                  };
                  })(file);
                  fRead.readAsDataURL(file); //URL representing the file's data.
              }
          });
      } else{
          alert("Your browser doesn't support File API!"); //if File API is absent
      }
    }
  });
  function loadPreview(input, id) {
    id = id || '#preview_profile_photo';
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            var img = $('<img/>').addClass('thumb').attr('src', e.target.result).width(200).height(150);
            $(id).html(img);
        };
        reader.readAsDataURL(input.files[0]);
    }
  }
  function getCities(state_id){
    stoken = "{{csrf_token()}}";
    dataSend = {state_id:state_id,'_token':stoken};
    $.ajax({
      type: 'POST',
      url: "{{URL::to('/all/cities')}}",
      data: dataSend,
      dataType: 'json',
      success: function(res){
        if(res.status=='success'){
          alert(res.data);  
        }
      }
    });
  }
</script>
@endsection