@extends('layouts.app')

@section('title', 'Book')

@section('content')

       <div class="row">

       <div class="col-md-6">

          <div class="panel panel-primary">

             <div class="panel-heading"><h3>{{title_case($book->name)}} <a href="{{url('/todo/'.$todo->id)}}" class="btn btn-warning btn-group-sm pull-right ">Edit</a></h3>

             </div>

                 <div class="panel-body">

                   {{$book->description}}

                 </div>

             <div class="panel-footer"><strong>Category:</strong> {{$book->category}}</div>    

             </div>

       </div>

     </div>

@endsection