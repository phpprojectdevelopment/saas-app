<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <title>Laravel CRUD App Example</title>
      <link rel="stylesheet" href="<?php echo e(asset('public/css/bootstrap.min.css')); ?>">
      <script src="<?php echo e(asset('public/js/jquery-3.1.1.min.js')); ?>"></script>
   </head>
   <body>
      <div class="container">
         <?php echo $__env->yieldContent('content'); ?>
      </div>
      <script src="" type="text/js"></script>
   </body>
</html>