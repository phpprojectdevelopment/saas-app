
            <div id="Contact" class="section">
                <div class="container">
                    <h1 class="section-head">Outlet Details and Enquiry Form</h1>
                    <div class="row">
                        <div class="col-md-8 ">
                            <div class="location">
                                <h1 class="sub">Outlets</h1>
                                <div class="sub">
                                    <div class="location-address">
                                     <p>
                                            <strong>Viva Honda Santacruz - </strong>
                                            S.V. Road, Santacruz(W), Mumbai-54. Tel: <a href="tel:+917777043437">+91-224377 7777 / 7777043437</a>
                                        </p>
                                        <p>
                                            <strong>Viva Honda Chandivali - </strong>
                                            No 35, Saki Vihar Rd, Opposite to Bharat Petrol Pump,Chandivali, Andheri East, Mumbai-72. Tel: <a href="tel:+919139000444">+91-224377 7777 / 9139000444</a>
                                        </p>
                                       
                                    </div>
                                </div>
                                <h1 class="sub">Workshop</h1>
                                <div class="sub">
                                    <div class="location-address">
                                        <p>
                                            <strong>Viva Honda Chandivali - </strong>
                                             No 35, Saki Vihar Rd, Opposite to Bharat Petrol Pump,Chandivali, Andheri East, Mumbai-72. Tel: <a href="tel:+918657458448">+91-8657458448</a>
                                        </p>
                                        
                                         <p>
                                            <strong>Viva Honda Kanjurmarg - </strong>
                                            Devidayal Stainless Steel Co. Compound, Off. Seth Govindram Jolly Marg, Kanjur Road, Kanjurmarg (E), Mumbai, Maharashtra 400042 <a href="tel:+919152010266">+91-9152010266</a>
                                        </p>
                                        
                                        
                                    </div>

                                </div>
                            </div>

                        </div>
                        <div id="form2" class="col-md-4 footer-enquire-form">
                            <div>
                                <h1 class="sub">Enquiry Form</h1>

                                <div class="sub">
                                    <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ScriptManager1', 'aspnetForm', [], [], [], 90, 'ctl00');
//]]>
</script>

                                    

                                    

<div class="no-border slider-form">
    <div class="">
        <span id="ctl00_EnquireForm2_lblMessage" class="successMsg" style="color:green;"></span>
    </div>
    <div class="formwrap">
        <div class="form-group">
            <input name="ctl00$EnquireForm2$txtName" type="text" id="ctl00_EnquireForm2_txtName" class="flat form-control" placeholder="Name" />
            <span id="ctl00_EnquireForm2_rfvName" class="text-danger" style="display:none;">Atleast 3 characters</span>
        </div>
        <div class="form-group">
            <input name="ctl00$EnquireForm2$txtPhone" type="text" id="ctl00_EnquireForm2_txtPhone" class="flat form-control" placeholder="Phone Number" />
            <!-- <span id="ctl00_EnquireForm2_rfvPhone" class="text-danger" style="display:none;">Please specify phone</span> -->
            <span id="ctl00_EnquireForm2_revTelno" class="text-danger" style="display:none;">Please specify valid phone</span>
        </div>
        <div class="form-group">
            <input name="ctl00$EnquireForm2$txtEmail" type="text" id="ctl00_EnquireForm2_txtEmail" class="flat form-control" placeholder="Email" />
            <!-- <input name="ctl00$EnquireForm2$txtSecEmail" type="text" id="ctl00_EnquireForm2_txtSecEmail" class="secemail" placeholder="E-mail" /> -->
            <!-- <span id="ctl00_EnquireForm2_rfvEmail" class="text-danger" style="display:none;">Please specify email-id</span> -->
            <span id="ctl00_EnquireForm2_revEmailId" class="text-danger" style="display:none;">Please enter valid email address</span>
        </div>
        <div class="">
            <textarea name="ctl00$EnquireForm2$txtMessage" rows="2" cols="20" id="ctl00_EnquireForm2_txtMessage" class="flat form-control" placeholder="Your message goes here...">
</textarea>
            <span id="ctl00_EnquireForm2_rfvMessage" class="text-danger" style="display:none;">Atleast 10 characters</span>
        </div>

    </div>
    <div style="margin: 15px 0;">
        <input type="submit" name="ctl00$EnquireForm2$lnkSave" value="Submit" id="ctl00_EnquireForm2_lnkSave" class="btn btn-viva btn-viva-rounded col-xs-12 col-md-6 form-group" />
        <div class="clearfix">
        </div>
    </div>

</div>
<div class="clearfix"></div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</form>


        <div id="footer" class="section">
            <div class="container-fluid">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 ">
                            <div class="row sitemap">
                                <div class="col-sm-2">
                                    <h5>The Honda Range</h5>
                                    <ul>
                                       
                                        <li><a href="honda-amaze">Amaze</a></li>
                                        <li><a href="honda-jazz">Jazz</a></li>
                                        <li><a href="honda-city">City</a></li>
                                        <li><a href="honda-civic">All New Civic</a></li>
                                        <li><a href="honda-br-v">All New BR-V</a></li>
                                        <li><a href="honda-cr-v">CR-V</a></li>
                                        <li><a href="honda-accord">Accord Hybrid</a></li>
                                    </ul>
                                </div>
                                <div class="col-sm-2">
                                    <h5>Shopping Tools</h5>
                                    <ul>
                                        <li><a href="#">Browse All Models</a></li>
                                        <li><a href="offers">Offers</a></li>
                                        <li><a href="test-drive-scheduler">Take A Test Drive</a></li>
                                        <li><a href="#Brochure">Brochure</a></li>
                                    </ul>
                                </div>
                                <div class="col-sm-2">
                                    <h5>Latest News</h5>
                                    <ul>
                                        <li><a href="#">News</a></li>
                                        <li><a href="#">Subscribe to Honda</a></li>
                                        <li><a href="#">Honda Magazine</a></li>
                                    </ul>
                                </div>
                                <div class="col-sm-2">
                                    <h5>About Us</h5>
                                    <ul>
                                        <li><a href="#">Corporate Policies</a></li>
                                        <li><a href="#">Careers</a></li>
                                        <li><a href="#">Environment</a></li>
                                    </ul>
                                </div>

                                <div class="col-sm-2">
                                    <h5>Get In Touch</h5>
                                    <ul>
                                        <li><a href="locate-us">Contact Us</a></li>
                                        <li><a href="#">FAQs</a></li>
                                        <li><a href="#">Environment</a></li>
                                    </ul>
                                    <ul>
                                        <li><a href="https://www.facebook.com/vivahondaserviceandsales/" target="_blank"><i class="fa fa-facebook-square fa-fw"></i>Facebook</a></li>
                                        <li><a href="https://www.youtube.com/watch?v=P5SMzdTXYQc" target="_blank"><i class="fa fa-youtube-square fa-fw"></i>Youtube</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="clearfix">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="subfooter">
            <div class="container">
                <div class="credits">
                    <p class="left">
                        &copy; Copyright VIVA HONDA. All Rights Reserved
                    </p>
                    <div>
                        <img src="<?php echo e(asset('public/images/footer-logo.jpg')); ?>" /></div>
                    <p class="text-center right">
                        <a href="https://www.facebook.com/vivahondaserviceandsales/" target="_blank"><i class="fa fa-facebook"></i></a><a href="#" target="_blank"><i class="fa fa-twitter"></i></a><a href="https://www.youtube.com/watch?v=P5SMzdTXYQc" target="_blank"><i class="fa fa-youtube"></i></a>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript" src="<?php echo e(asset('public/js/plugins.min.js')); ?>"></script>
    <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.0.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/js/script.js')); ?>" id="scripts"></script>
<script>
// Analytics Code for V i v a  H o n d a Added on 04-03-17
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-93016774-1', 'auto');
  ga('send', 'pageview');

</script>
<!--Start of Zendesk Chat Script-->
<script type='text/javascript'>
    (function(I, _, T, i, c, k, s) { if (I.iticks) return; I.iticks = { host: c, settings: s, clientId: k, cdn: _, queue: [] }; var h = T.head || T.documentElement; var e = T.createElement(i); var l = I.location; e.async = true; e.src = (_ || c) + '/client/inject-v2.min.js'; h.insertBefore(e, h.firstChild); I.iticks.call = function(a, b) { I.iticks.queue.push([a, b]); }; })(window, 'https://cdn.intelliticks.com/prod/common', document, 'script', 'https://app.intelliticks.com', 'yMFdnC2uJib77iDKn_c', {});
    </script>
<!--End of Zendesk Chat Script-->
<!-- Start of StatCounter Code for Default Guide -->
<script type="text/javascript">
var sc_project=11612961; 
var sc_invisible=1; 
var sc_security="b5a6d8db"; 
var scJsHost = (("https:" == document.location.protocol) ?
"https://secure." : "http://www.");
</script>
<script type="text/javascript"
src="https://www.statcounter.com/counter/counter.js"
async></script>
<noscript><div class="statcounter"><a title="Web Analytics"
href="http://statcounter.com/" target="_blank"><img
class="statcounter"
src="//c.statcounter.com/11612961/0/b5a6d8db/1/" alt="Web
Analytics"></a></div></noscript>
<!-- End of StatCounter Code for Default Guide -->
<style rel='stylesheet' type='text/css'>

div#bottom-right {
position: fixed;

padding: 5px;
margin-bottom:30%;
}
div#bottom-right {
bottom: 0;
left: 0;
}
</style>
<div id='bottom-right'>
<a href="https://api.whatsapp.com/send?phone=919320893208&amp;text=Hi" style="text-decoration:none;color:#ffffff; font-family:'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 20px;"><img data-mobile-src="<?php echo e(asset('public/images/whastapp.png')); ?>" data-desktop-src="<?php echo e(asset('public/images/whatsapp-button.png')); ?>" alt="Honda Special Offers"> </a>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
    window.addEventListener('load', function() {
        if (jQuery('.successMsg:contains("sending an enquiry")').is(":visible")) {
          gtag('event', 'conversion', {
            'send_to': 'AW-818821838/ErtwCJjE9X8QzvW4hgM'
          });
        }
        if (jQuery('.success:contains("Thank you for sending an enquiry.")').is(":visible")) {
          gtag('event', 'conversion', {
            'send_to': 'AW-818821838/2RpSCPruhYABEM71uIYD'
          });

        }
    });

    $("#ctl00_EnquireForm2_lnkSave").on('click', function(){
        ctl00_EnquireForm2_txtName = $("#ctl00_EnquireForm2_txtName").val();
        ctl00_EnquireForm2_txtPhone = $("#ctl00_EnquireForm2_txtPhone").val();
        ctl00_EnquireForm2_txtEmail = $("#ctl00_EnquireForm2_txtEmail").val();
        ctl00_EnquireForm2_txtMessage = $("#ctl00_EnquireForm2_txtMessage").val();

        if(ctl00_EnquireForm2_txtName=='' || ctl00_EnquireForm2_txtPhone=='' || ctl00_EnquireForm2_txtEmail=='' || ctl00_EnquireForm2_txtMessage==''){
            $("#ctl00_EnquireForm2_rfvName,#ctl00_EnquireForm2_revTelno,#ctl00_EnquireForm2_revEmailId,#ctl00_EnquireForm2_rfvMessage").show();
            return false;
        }

        if(ctl00_EnquireForm2_txtName!='' && ctl00_EnquireForm2_txtName!=null && ctl00_EnquireForm2_txtName.length>2){
            $("#ctl00_EnquireForm2_rfvName").hide();
        }
        if(ctl00_EnquireForm2_txtPhone!='' && ctl00_EnquireForm2_txtPhone.length==10){
            $("#ctl00_EnquireForm2_revTelno").hide();
        }
        if(ctl00_EnquireForm2_txtEmail!='' && emailValid(ctl00_EnquireForm2_txtEmail)==true){
            $("#ctl00_EnquireForm2_revEmailId").hide();
        }
        if(ctl00_EnquireForm2_txtMessage!='' && ctl00_EnquireForm2_txtMessage!=null && ctl00_EnquireForm2_txtMessage.length>9){
            $("#ctl00_EnquireForm2_rfvMessage").hide();
        }

        data = {name:ctl00_EnquireForm2_txtName,phone_number:ctl00_EnquireForm2_txtPhone,email:ctl00_EnquireForm2_txtEmail,message:ctl00_EnquireForm2_txtMessage, '_token':'<?php echo e(csrf_token()); ?>'};

        $.ajax({
            url: 'submitEnquiry',
            type:'POST',
            data: data,
            dataType: "JSON",
            success:function(response){
                /*if(response.status=='failed'){
                    if (response.message=='OTP expired, please request new OTP') {
                       $("#errMsg").html("<p>"+response.message+"</p>").show(); 
                    }else{
                        $("#errMsg").html("<p>"+response.message+"</p>").show();   
                    }
                }else if (response.status=='success') {
                    if(response.message=="OTP sent"){
                        $("#msg").html("<p>Please enter the OTP "+response.otp+" sent to " + $("#mobile_or_email").val() + "</p>").show();
                    }
                    if(response.message=="Welcome"){
                        location.reload(true);
                    }
                } else {
                    // alert('Something went wrong, sorry please try again!');
                    // return false;
                }*/
                
                if(response=='success'){
                    $("#ctl00_EnquireForm2_rfvName,#ctl00_EnquireForm2_revTelno,#ctl00_EnquireForm2_revEmailId,#ctl00_EnquireForm2_rfvMessage").hide();
                    $("#ctl00_EnquireForm2_txtName, #ctl00_EnquireForm2_txtPhone, #ctl00_EnquireForm2_txtEmail, #ctl00_EnquireForm2_txtMessage").val("");
                    $("#ctl00_EnquireForm2_lblMessage").html('Thank you for sending an enquiry. We will get in touch with you soon.').show();
                }

            }
        });
    });

    function emailValid(email){
        atpos = email.indexOf("@");
        dotpos = email.lastIndexOf(".");
        if(atpos<1 || dotpos<atpos+2 || dotpos+2>=email.length){
            return false;
        }
        return true;
    }

    if($("#ctl00_EnquireForm2_txtPhone")){
        $("#ctl00_EnquireForm2_txtPhone").attr("maxlength", 10);
        $("#ctl00_EnquireForm2_txtPhone").attr("onkeypress", "return onlyNumberKey(event)");
    }

    function onlyNumberKey(evt) {
        // Only ASCII charactar in that range allowed 
        var ASCIICode = (evt.which) ? evt.which : evt.keyCode 
        if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57)) 
            return false; 
        return true; 
    }
</script>

</body>
</html>
